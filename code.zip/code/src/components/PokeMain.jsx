import React from "react";
import PokeCard from "./PokeCard";
import PokeInfo from "./PokeInfo";
import axios from "axios";
import { useState } from "react";
import { useEffect } from "react";
const PokeMain = () => {
  const [pokeData, setPokeData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [url, setUrl] = useState("https://pokeapi.co/api/v2/pokemon/");
  const [nextUrl, setNextUrl] = useState();
  const [prevUrl, setPrevUrl] = useState();
  const [pokeDex, setPokeDex] = useState();
  // const [text, setText] = useState();

  const pokeFun = async () => {
    setLoading(true);
    const res = await axios.get(url);
    console.log(res, "res");
    setNextUrl(res.data.next);
    setPrevUrl(res.data.previous);
    getPokemon(res.data.results);
    console.log(pokeData, "pokeData");
    setLoading(false);
    console.log(res, "res");
  };

  const getPokemon = async (res) => {
    console.log(res, "res");
    res.map(async (item) => {
      console.log(item);
      const result = await axios.get(item.url);
      setPokeData((state) => {
        state = [...state, result.data];
        state.sort((a, b) => (a.id > b.id ? 1 : -1));
        return state;
      });
    });
  };

  useEffect(() => {
    pokeFun();
  }, [url]);

  // const FilterSection = () => {
  //   return (
  //     <div className="fulll">
  //       <form onSubmit={(e) => e.preventDefault()}>
  //         <input
  //           className="wi-full"
  //           type="text"
  //           name="text"
  //           onChange={(e) => setText(e.target.value)}
  //           placeholder="Search by pokemon name"
  //         />
  //       </form>
  //     </div>
  //   );
  // };

  return (
    <>
      <div className="container">
        <div className="left-content">
          {/* <FilterSection /> */}
          <PokeCard
            pokemon={pokeData}
            loading={loading}
            infoPokemon={(poke) => setPokeDex(poke)}
          />
          {/* {console.log(pokeData, "pokdata")} */}

          <div className="btn-group">
            {prevUrl && (
              <button
                onClick={() => {
                  setPokeData([]);
                  setUrl(prevUrl);
                }}
              >
                Previous
              </button>
            )}

            {nextUrl && (
              <button
                onClick={() => {
                  setPokeData([]);
                  setUrl(nextUrl);
                }}
              >
                Next
              </button>
            )}
          </div>
        </div>
        <div className="right-content">
          <PokeInfo data={pokeDex} />
        </div>
      </div>
    </>
  );
};
export default PokeMain;
