import React, { useEffect, useState } from "react";
const PokeCard = ({ pokemon, loading, infoPokemon }) => {
  // console.log(pokemon);

  const [query, setQuery] = useState("");

  const FilterSection = () => {
    return (
      <div className="fulll">
        {/* {console.log(pokemon[0].name, "some")} */}
        <form onSubmit={(e) => e.preventDefault()}>
          <input
            className="wi-full"
            type="text"
            name="query"
            // value={text}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search by pokemon name"
          />
        </form>
      </div>
    );
  };
  const handleInfiniteScroll = () => {
    console.log("scrollHeight" + document.documentElement.scrollHeight);
    console.log("innerHeight" + window.innerHeight);
    console.log("scrollHeight" + document.documentElement.scrollTop);
    try {
      if (
        window.innerHeight + document.documentElement.scrollTop >=
        document.documentElement.scrollHeight + 1
      ) {
      }
    } catch (err) {
      console.log(err);
    }
  };
  useEffect(() => {
    window.addEventListener("scroll", handleInfiniteScroll);
  }, []);

  return (
    <>
      <div>
        {/* {console.log(
        pokemon ? pokemon.map((user) => user.name, "me chala") : null
      )} */}
        <FilterSection />
        {pokemon
          ? pokemon
              .filter((item) => item.name.toLowerCase().includes(query))
              .map((item) => {
                return (
                  <div
                    className="card"
                    key={item.id}
                    onClick={() => infoPokemon(item)}
                  >
                    {console.log(
                      pokemon.filter((user) => user.base_experience)
                    )}
                    <h2>{item.id}</h2>
                    <img src={item.sprites.front_default} alt="pokeImage" />
                    <h2>{item.name}</h2>
                  </div>
                );
              })
          : null}
      </div>
    </>
  );
};
export default PokeCard;
