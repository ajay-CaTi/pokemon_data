import "./App.css";
// import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
// import "../node_modules/bootstrap/dist/js/bootstrap.min.js";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
// import PokeCard from "./components/PokeCard";
import PokeMain from "./components/PokeMain";
import PokeInfinite from "./components/PokeInfinite";
// import Navbar from "./components/Navbar";

function App() {
  return (
    <div>
      <h1>This is app</h1>
      <Router>
        {/* <Navbar /> */}
        <Routes>
          <Route path={"/"} element={<PokeMain />} />
          <Route path={"/pokinfinite"} element={<PokeInfinite />} />
        </Routes>
      </Router>
    </div>
  );
}
// fatal: unable to access 'https://github.com/ajay-CaTi/pokemon.git/': The requested URL returned error: 403 ERROR OCCURED AT TIME OF PUSHING CODE :: -- MYBAD

export default App;
